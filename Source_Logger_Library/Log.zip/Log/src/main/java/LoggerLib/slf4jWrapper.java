package LoggerLib;



/*import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;

import org.apache.logging.log4j.MarkerManager;*/

/*import org.slf4j.Logger;*/

import org.slf4j.Marker;
import org.slf4j.MarkerFactory;
/*import org.slf4j.event.LoggingEvent;
import org.springframework.boot.logging.LogLevel;*/

public class slf4jWrapper implements ILogger{

	org.slf4j.Logger mLogger;
	String type;

	public static String MSID;

	public slf4jWrapper(String a) {

		mLogger = UCPLogger.getSlf4jLogger(a);
		type = mLogger.getName();
	}

	public String AppendMSID(String message) {
		return "(" + UCPLogger.MSID + " - " + type + " ) - " + message;

	}

	public void Debug(String messageTemplate) {
		mLogger.debug(AppendMSID(messageTemplate));

	}

	public void Debug(String message, Exception exception) {
		mLogger.debug(message, exception);

	}

	public void Warn(String messageTemplate) {
		mLogger.warn(AppendMSID(messageTemplate));
	}

	public void Warn(String messageTemplate, Exception exception) {
		mLogger.warn(AppendMSID(messageTemplate), exception);

	}

	public void Info(String messageTemplate) {
		mLogger.info(AppendMSID(messageTemplate));
	}

	public void Info(String messageTemplate, Exception exception) {
		mLogger.info(AppendMSID(messageTemplate), exception);

	}
	
	  public void Fatal(String messageTemplate) {
	  
	  Marker fatal = MarkerFactory.getMarker("FATAL");
	  mLogger.error(fatal, AppendMSID(messageTemplate)); }
	  
	  public void Fatal(String messageTemplate, Exception exception) { 
		  Marker fatal  = MarkerFactory.getMarker("FATAL");
	  mLogger.error(fatal, AppendMSID(messageTemplate), exception);
	  
	  }
	 

	/*
	 * public void fatal(String messageTemplate) {
	 * 
	 * 
	 * mLogger.fatal(AppendMSID(messageTemplate)); }
	 * 
	 * public void fatal(String messageTemplate, Exception exception) {
	 * 
	 * mLogger.fatal(AppendMSID(messageTemplate), exception);
	 * 
	 * }
	 */

	public void Error(String messageTemplate) {
		mLogger.error(AppendMSID(messageTemplate));
	}

	public void Error(String messageTemplate, Exception exception) {
		mLogger.error(AppendMSID(messageTemplate), exception);

	}

	public void Trace(String messageTemplate) {
		mLogger.trace(AppendMSID(messageTemplate));
	}

	public void Trace(String messageTemplate, Exception exception) {
		mLogger.trace(AppendMSID(messageTemplate), exception);

	}

	
	  public void Verbose(String messageTemplate) {
		  Marker verbose =  MarkerFactory.getMarker("VERBOSE");
	  mLogger.debug(verbose, AppendMSID(messageTemplate)); }
	  
	  public void Verbose(String messageTemplate, Exception exception) { 
		  Marker verbose = MarkerFactory.getMarker("VERBOSE");
	  mLogger.debug(verbose, AppendMSID(messageTemplate), exception);
	  
	  }
	 

}
