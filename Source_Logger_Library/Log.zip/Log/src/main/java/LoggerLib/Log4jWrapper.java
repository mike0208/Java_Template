package LoggerLib;




import org.apache.logging.log4j.Marker;

import org.apache.logging.log4j.MarkerManager;





/*import org.slf4j.Marker;
import org.slf4j.MarkerFactory;*/


public class Log4jWrapper implements ILogger {


	org.apache.logging.log4j.Logger mLogger;
	String type;

	public static String MSID;

	public Log4jWrapper(String b){
	
		 mLogger = UCPLogger.getLog4jLogger(b); 
	type = mLogger.getName();
	}


	


	public String AppendMSID(String message)
	{
	return "(" + UCPLogger.MSID +" - "+ type+" ) - " + message; 
		
	}
	
	public void Debug(String messageTemplate)
	{
	 mLogger.debug(AppendMSID(messageTemplate));
		
	}
	
	public void Debug(String message, Exception exception) 
	{
		 mLogger.debug(message, exception);
		
	}
	
	public void Warn(String messageTemplate)
	{
		mLogger.warn(AppendMSID(messageTemplate));
	}
	
	public void Warn(String messageTemplate, Exception exception) 
	{
		mLogger.warn(AppendMSID(messageTemplate), exception);
		
	}
	
	public void Info(String messageTemplate)
	{
		 mLogger.info(AppendMSID(messageTemplate));
	}
	
	public void Info( String messageTemplate, Exception exception) 
	{
		mLogger.info(AppendMSID(messageTemplate), exception);
		
	}
	
	public void Fatal(String messageTemplate)
	{
		
		 Marker fatal = MarkerManager.getMarker("FATAL");
		 mLogger.error(fatal, AppendMSID(messageTemplate));
	}
	
	public void Fatal(String messageTemplate, Exception exception) 
	{
		Marker fatal = MarkerManager.getMarker("FATAL");
		  mLogger.error(fatal, AppendMSID(messageTemplate), exception);
		 
	}
	/*
	 * public void fatal(String messageTemplate) {
	 * 
	 * 
	 * mLogger.fatal(AppendMSID(messageTemplate)); }
	 * 
	 * public void fatal(String messageTemplate, Exception exception) {
	 * 
	 * mLogger.fatal(AppendMSID(messageTemplate), exception);
	 * 
	 * }
	 */
	
	public void Error(String messageTemplate)
	{
		mLogger.error(AppendMSID(messageTemplate));
	}
	
	public void Error(String messageTemplate, Exception exception) 
	{
		 mLogger.error(AppendMSID(messageTemplate), exception);
		
	}
	
	public void Trace(String messageTemplate)
	{
		mLogger.trace(AppendMSID(messageTemplate));
	}
	
	public void Trace(String messageTemplate, Exception exception) 
	{
		mLogger.trace(AppendMSID(messageTemplate), exception);
		 
	}

	
	public void Verbose(String messageTemplate)
	{
		Marker verbose = MarkerManager.getMarker("VERBOSE");
		mLogger.debug(verbose, AppendMSID(messageTemplate));
	}

	public void Verbose(String messageTemplate, Exception exception) 
	{
		Marker verbose = MarkerManager.getMarker("VERBOSE");
		mLogger.debug(verbose, AppendMSID(messageTemplate), exception);
	
	}









	/*
	 * public void verbose(String messageTemplate) { final Level VERBOSE =
	 * Level.forName("VERBOSE", 550);
	 * 
	 * mLogger.log(VERBOSE, AppendMSID(messageTemplate)); }
	 * 
	 * public void verbose(String messageTemplate, Exception exception) { final
	 * Level VERBOSE = Level.forName("VERBOSE", 550); mLogger.log(VERBOSE,
	 * AppendMSID(messageTemplate), exception);
	 * 
	 * }
	 */
	
//	
//	 private <varargs> void PublishToActiveMQ(LogEventLevel logLevel,Exception exception, string messageTemplate, varargs object[] propertyValues)
//     {
//         string message = messageTemplate;
//         string[] propertyMesg;
//         if (exception != null)
//             message = message + exception.ToString();
//         if (propertyValues != null && propertyValues.Count() > 0)
//         {
//             if (propertyValues[0].GetType().ToString().Contains("System"))
//             {
//                 propertyMesg = new string[propertyValues.Count()];
//                 for (int i = 0; i < propertyValues.Count(); i++)
//                 {
//                     propertyMesg[i] = propertyValues[i].ToString();
//                 }
//                 message = string.Format(message, propertyMesg);
//             }
//             else
//             {
//                 propertyMesg = ReadProperty(propertyValues);
//                 if (propertyMesg != null)
//                     message = string.Format(message, propertyMesg);
//                 else
//                     message = string.Format(message, propertyValues);
//             }
//         }
//         message = "{" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff zzz") + "} { " + logLevel.ToString() + "} " + AppendMSID(message);
//       Logger1.PublishToActiveMQ(message);
//
//     }
//	 private <varargs> String[] ReadProperty(varargs object[] propertyValues)
//     {
//         string[] desriptionMessage = new string[propertyValues.Count()];
//         try
//         {               
//             for (int i= 0;i<propertyValues.Count();i++)
//             {
//                 object item = propertyValues[i];
//                 string message = "";
//                 foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(item))
//                 {
//                     string name = descriptor.Name;
//                     if (message != "")
//                         message = message + ", ";
//                     message = message + name + " - " + descriptor.GetValue(item);
//                 }
//                 desriptionMessage[i] = message;
//             }
//         }
//         catch
//         {
//             return null;
//         }
//
//         return desriptionMessage;
//     }
}
