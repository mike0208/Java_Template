package LoggerLib;


public interface ILogger
    {
        void Debug(String messageTemplate);
       
        void Debug(String messageTemplate, Exception exception);
        
        void Verbose(String messageTemplate);
       
        void Verbose(String messageTemplate, Exception exception);
        void Warn(String messageTemplate);
       
      
        void Warn(String messageTemplate, Exception exception);
        
        void Trace(String messageTemplate);
        
        void Trace(String messageTemplate, Exception exception);
        void Error(String messageTemplate);
      
        void Error(String messageTemplate, Exception exception);
        

        
        void Fatal(String messageTemplate);
       
        void Fatal(String messageTemplate, Exception exception);
        
        void Info(String messageTemplate);
        void Info(String messageTemplate, Exception exception);
        

    }

