package LoggerLib;


/*import java.util.logging.Level;*/

import org.slf4j.Logger;
//import org.slf4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.slf4j.LoggerFactory;


public class UCPLogger {
	public enum LoggerType
	{
	    Log4j,
	    slf4j
	}
	
	  protected static String MSID;
	  private static org.apache.logging.log4j.Logger logger1;
	  private static Logger logger;
	  
																																																																																			/*
																																																																																			 * public static ILogger LoggerLib(String type) { if(type == LoggerType) {
																																																																																			 * return new } }
																																																																																			 */
	  
	  public static void LoggerConfigurations(String msid) 
	  { MSID = msid;
	  
	  
	  }
	  
	  
	  public synchronized static Logger getSlf4jLogger(String a) {
	  
	  if (logger!= null) 
		  return  logger; 
	  return  logger =  LoggerFactory.getLogger(a);
	  }
	  
	  public synchronized static org.apache.logging.log4j.Logger getLog4jLogger(String b) {
		  
		  if (logger1!= null) 
			  return  logger1; 
		  return  logger1 =  LogManager.getLogger(b);
		  }
	  
}
	 


	


    


