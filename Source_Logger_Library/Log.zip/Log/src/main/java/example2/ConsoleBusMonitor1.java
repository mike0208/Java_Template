package example2;


/*import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;*/
import LoggerLib.*;




/*@ComponentScan(basePackages = "LoggerLib")
@PropertySource("classpath:application.properties")*/
public class ConsoleBusMonitor1 {

	/*
	 * static { System.setProperty("logback.configurationFile",
	 * "/path/to/config.xml");}
	 */
	
	static Log4jWrapper mLogger = new Log4jWrapper("ConsoleBusMonitor1.class");
	        
	     public static void main(String[] args) {   	
	    	
	    System.out.println("World");
	    	mLogger.Error("Error");
	    	mLogger.Warn("warn");
	    	mLogger.Trace("Trace the issue");
	            mLogger.Debug("Before Assign Contest");           
	            mLogger.Debug("After Assign Contest");
	            mLogger.Error("ErrorHandling");
	          
	         System.out.println("Hello");
//	            TestProperties testProperties = new TestProperties() { RawData = "Raw1", Serivece = "service Started", State = Status.Running };
//	            mlogger.Fatal("Error With Properties -{0} - Test", testProperties);
//	         SpringApplication.run(ConsoleBusMonitor.class, args);
	        }
}
