package example2;

/*
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;*/
import LoggerLib.*;


/*@ComponentScan(basePackages = "LoggerLib")
@PropertySource("classpath:application.properties")*/
public class ConsoleBusMonitor {

	/*
	 * static { System.setProperty("logback.configurationFile",
	 * "/path/to/config.xml");}
	 */
	
	static slf4jWrapper mLogger = new slf4jWrapper("ConsoleBusMonitor.class");
	        
	     public static void main(String[] args) {   	
	    	
	    System.out.println("World");
	    	mLogger.Error("Error");
	    	mLogger.Info("Detailed Information");
	            mLogger.Debug("Before Assign Contest");           
	            mLogger.Debug("After Assign Contest");
		/*
		 * mLogger.Fatal("fatalHandling"); mLogger.Verbose("VerbHandling");
		 */
	            mLogger.Error("ErrorHandling");
	            
	          
	         System.out.println("Hello");
//	            TestProperties testProperties = new TestProperties() { RawData = "Raw1", Serivece = "service Started", State = Status.Running };
//	            mlogger.Fatal("Error With Properties -{0} - Test", testProperties);
//	         SpringApplication.run(ConsoleBusMonitor.class, args);
	        }
}
